<?php

$con = mysqli_connect("localhost","root","","sheba") or die("Connection was not established");


function insertPost(){
	if(isset($_POST['sub'])){
		global $con;
		global $user_id;
	
}
}


?>
